Upload to GitHub, keep structure:
/worker/index.js
/public/index.html
manifest.json
Then deploy via Cloudflare Pages (output dir: public).
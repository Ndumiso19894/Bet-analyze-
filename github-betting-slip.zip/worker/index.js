export default {
  async fetch(request) {
    return new Response("Worker running");
  }
};